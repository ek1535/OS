Linker Lab (Lab 1) for Operating Systems Spring 2016
1 source code file is part of the submission:
	-> TwoPassLinker.java

To compile the lab, execute:
$javac TwoPassLinker.java
An executable named "TwoPassLinker" will be created

To rune the lab, execute
$java TwoPassLinker <inputfile>


The code was tested on mauler.cims.nyu.edu


